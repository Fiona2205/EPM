package com.sunlian.epm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EpmApplicationTests {

	@Test
	void contextLoads() {
	}

}

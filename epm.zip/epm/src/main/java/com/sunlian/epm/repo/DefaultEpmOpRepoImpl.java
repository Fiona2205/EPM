package com.sunlian.epm.repo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunlian.epm.model.EquityOpEO;

@Service
public class DefaultEpmOpRepoImpl implements EpmOpRepo{

	@Autowired
	private DefaultDB<EquityOpEO> db;

	@Override
	public void saveOrUpdateEmpOp(EquityOpEO eo) {
		// TODO Auto-generated method stub
		
	}

	
	
	

}

package com.sunlian.epm.model;

import java.util.Date;

/**
 * 挂单明细
 * @author cienet
 *
 */
public class EquityEO {
	
	/**
	 * 挂单id
	 */
	private long tradeId; 
	
	/**
	 * 安全code
	 */
	private String securityCode;
	
	/**
	 * 股票数量
	 */
	private int quantity;
	
	/**
	 * 更新时间
	 */
	private Date updateTime;
	
	/**
	 * 是否可用
	 */
	private boolean enable;

	public long getTradeId() {
		return tradeId;
	}

	public void setTradeId(long tradeId) {
		this.tradeId = tradeId;
	}

	public String getSecurityCode() {
		return securityCode;
	}

	public void setSecurityCode(String securityCode) {
		this.securityCode = securityCode;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public boolean isEnable() {
		return enable;
	}

	public void setEnable(boolean enable) {
		this.enable = enable;
	}

	@Override
	public String toString() {
		return "EquityEO [tradeId=" + tradeId + ", securityCode=" + securityCode + ", quantity=" + quantity
				+ ", updateTime=" + updateTime + ", enable=" + enable + "]";
	}
	


	

}

package com.sunlian.epm.service.impl;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunlian.epm.domain.EquityOpVO;
import com.sunlian.epm.domain.Status;
import com.sunlian.epm.model.EquityOpEO;
import com.sunlian.epm.repo.EpmOpRepo;
import com.sunlian.epm.service.EquityService;

@Service
public class EquityServiceImpl implements EquityService{

	@Autowired
	private EpmOpRepo epmOpRepo;
	
	private AtomicLong transactionId = new AtomicLong();
	private AtomicLong tradeId = new AtomicLong();
	private AtomicLong version = new AtomicLong();
	
	
	@Override
	public Status operateEquity(EquityOpVO equityOpVO) {
		// TODO Auto-generated method stub
		if(!equityOpVO.checkParams()) {
			return new Status(2001,"参数异常，请检查");
		}
		EquityOpEO equityOpEO = buildEquityOpEO(equityOpVO);
		
		return new Status(200,"操作成功");
	}


	private EquityOpEO buildEquityOpEO(EquityOpVO equityOpVO) {
		// TODO Auto-generated method stub
		EquityOpEO equityEO = new EquityOpEO();
		equityEO.setTransactionId(transactionId.get());
		//交易号
		equityEO.setTradeId(equityOpVO.getTradeId() == null ?tradeId.get():equityOpVO.getTradeId());
		equityEO.setSecurityCode(equityOpVO.getSecurityCode());
		equityEO.setUserOps(equityOpVO.getUserOps());
		equityEO.setDataOps(equityOpVO.getDataOps());
		equityEO.setQuantity(equityOpVO.getQuantity());
		//版本号更新
//		equityEO.setVersion(equityOpVO.getTradeId() == null?version.get());
		
		return equityEO;
	}

	
	
	
}

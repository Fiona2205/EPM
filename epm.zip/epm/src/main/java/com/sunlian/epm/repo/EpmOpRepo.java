package com.sunlian.epm.repo;

import com.sunlian.epm.model.EquityEO;
import com.sunlian.epm.model.EquityOpEO;

/**
 * 操作信息持久化
 * @author cienet
 *
 */
public interface EpmOpRepo {
	
	/**
	 * 保存更新股票操作
	 * @param eo
	 */
	void saveOrUpdateEmpOp(EquityOpEO eo);
	
}

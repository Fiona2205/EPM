package com.sunlian.epm.repo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sunlian.epm.model.EquityEO;

@Component
public class DefaultEpmRepoImpl implements EpmRepo{

	@Autowired
	private DefaultDB<EquityEO> db;

	@Override
	public void saveOrUpdateEmpOp(EquityEO e) {
		// TODO Auto-generated method stub
		
	}
	
	
	

}

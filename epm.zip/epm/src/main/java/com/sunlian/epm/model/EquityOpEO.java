package com.sunlian.epm.model;

/**
 * 挂单明细
 * @author cienet
 *
 */
public class EquityOpEO {
	/**
	 * 事件id
	 */
	private Long transactionId;  
	
	/**
	 * 挂单id
	 */
	private Long tradeId; 
	
	/**
	 * 版本号
	 */
	private Integer version;
	
	/**
	 * 安全code
	 */
	private String securityCode;
	
	/**
	 * 股票数量
	 */
	private Integer quantity;
	
	/**
	 * 数据操作
	 */
	private String dataOps;
	
	/**
	 * 用户行为
	 */
	private String userOps;

	public long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public long getTradeId() {
		return tradeId;
	}

	public void setTradeId(long tradeId) {
		this.tradeId = tradeId;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public String getSecurityCode() {
		return securityCode;
	}

	public void setSecurityCode(String securityCode) {
		this.securityCode = securityCode;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getDataOps() {
		return dataOps;
	}

	public void setDataOps(String dataOps) {
		this.dataOps = dataOps;
	}

	public String getUserOps() {
		return userOps;
	}

	public void setUserOps(String userOps) {
		this.userOps = userOps;
	}

	@Override
	public String toString() {
		return "Equity [transactionId=" + transactionId + ", tradeId=" + tradeId + ", version=" + version
				+ ", securityCode=" + securityCode + ", quantity=" + quantity + ", dataOps=" + dataOps + ", userOps="
				+ userOps + "]";
	}
	

}

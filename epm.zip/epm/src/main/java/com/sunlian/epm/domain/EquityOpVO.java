package com.sunlian.epm.domain;

import org.springframework.util.StringUtils;

/**
 * 挂单明细
 * @author cienet
 *
 */
public class EquityOpVO {
	
	/**
	 * 安全code
	 */
	private String securityCode;
	
	/**
	 * 挂单id
	 */
	private Long tradeId; 
	
	/**
	 * 股票数量
	 */
	private Integer quantity;
	
	
	public Long getTradeId() {
		return tradeId;
	}


	public void setTradeId(Long tradeId) {
		this.tradeId = tradeId;
	}


	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	/**
	 * 用户行为   买 / 卖  
	 */
	private String userOps;
	
	/**
	 * 数据行为   插入  更新  取消 
	 */
	private String dataOps;


	public String getSecurityCode() {
		return securityCode;
	}


	public void setSecurityCode(String securityCode) {
		this.securityCode = securityCode;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public String getUserOps() {
		return userOps;
	}


	public void setUserOps(String userOps) {
		this.userOps = userOps;
	}


	

	public String getDataOps() {
		return dataOps;
	}


	public void setDataOps(String dataOps) {
		this.dataOps = dataOps;
	}


	public boolean checkParams() {
		
		if(StringUtils.isEmpty(securityCode) || quantity == null ||	StringUtils.isEmpty(userOps) ||StringUtils.isEmpty(dataOps) ) {
			return false;
		}
		return true;
	}
	
	

}

package com.sunlian.epm.service;

import com.sunlian.epm.domain.Status;
import com.sunlian.epm.domain.EquityOpVO;

public interface EquityService {

	/*
	 * 股票操作
	 */
	/**
	 * 股票信息接口
	 * @return
	 */
	Status operateEquity(EquityOpVO equityOp);
}

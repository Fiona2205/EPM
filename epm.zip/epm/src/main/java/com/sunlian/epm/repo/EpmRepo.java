package com.sunlian.epm.repo;

import org.springframework.stereotype.Component;

import com.sunlian.epm.domain.Status;
import com.sunlian.epm.model.EquityEO;


/**
 * 股票信息持久化
 * @author cienet
 *
 */
public interface EpmRepo {

	/**
	 * 保存更新股票信息
	 * @return
	 */
	void saveOrUpdateEmpOp(EquityEO e);
}

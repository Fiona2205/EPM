package com.sunlian.epm.domain;

public class Status {
	
	/**
	 * 操作码
	 */
	private Integer code;
	
	/**
	 * 响应信息
	 */
	private String message;
	
	
	

	public Status(Integer code, String message) {
		super();
		this.code = code;
		this.message = message;
	}

	public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "Status [code=" + code + ", message=" + message + "]";
	}

	
	
}

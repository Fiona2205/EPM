package com.sunlian.epm.repo;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Component;

@Component
public class DefaultDB<T>{
	
	private volatile  ConcurrentHashMap  db = new ConcurrentHashMap<String,T>();
	
	/**
	 * 增
	 */
	public void saveOrUpdate(T t) {
		
		//更新删除操作
		
		//持久化操作
	}
	
	/**
	 * 删
	 */
	public void del(T t) {
		//删除操作 - 逻辑删
		
		//持久化操作
	}
	
	/**
	 * 查所有
	 * @return
	 */
	public List<T> queryInfoAll() {
		
		return null;
	}
	 
	/**
	 * 指定securityCode
	 * @return
	 */
	public T queryInfo(String code) {
		
		return null;
	}
	
	

}
